import os
import sqlite3

DB_FILE = os.path.join(os.path.dirname(__file__), "estudiantes.db")


def conectar_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def crear_tabla():
    conn = conectar_db()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS estudiantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            edad INTEGER NOT NULL,
            curso TEXT NOT NULL,
            calificaciones TEXT NOT NULL,
            promedio REAL NOT NULL,
            estado TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def registrar_estudiante(nombre, edad, curso, calificaciones, promedio, estado):
    conn = conectar_db()
    conn.execute(
        """
        INSERT INTO estudiantes (nombre, edad, curso, calificaciones, promedio, estado)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (nombre, int(edad), curso, calificaciones, promedio, estado),
    )
    conn.commit()
    conn.close()


def obtener_todos_estudiantes():
    conn = conectar_db()
    rows = conn.execute(
        "SELECT id, nombre, edad, curso, calificaciones, promedio, estado FROM estudiantes ORDER BY nombre"
    ).fetchall()
    conn.close()
    return rows


def buscar_estudiante(nombre_buscar):
    conn = conectar_db()
    rows = conn.execute(
        "SELECT id, nombre, edad, curso, calificaciones, promedio, estado FROM estudiantes WHERE LOWER(nombre) LIKE ? ORDER BY nombre",
        (f"%{nombre_buscar.lower()}%",),
    ).fetchall()
    conn.close()
    return rows


def obtener_resumen():
    conn = conectar_db()
    rows = conn.execute(
        "SELECT nombre, curso, promedio, estado FROM estudiantes ORDER BY nombre"
    ).fetchall()
    conn.close()
    return rows
