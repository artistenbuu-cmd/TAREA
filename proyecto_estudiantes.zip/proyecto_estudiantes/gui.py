import tkinter as tk
from tkinter import ttk, messagebox

from database import buscar_estudiante, obtener_resumen, obtener_todos_estudiantes, registrar_estudiante
from models import CARRERAS, calcular_promedio, convertir_a_lista, obtener_estado


class StudentManagerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema de gestión de estudiantes")
        self.geometry("980x650")
        self.configure(bg="#edf2f7")
        self._setup_style()
        self._create_widgets()

    def _setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TLabel", background="#edf2f7", foreground="#1f2937", font=("Segoe UI", 10))
        style.configure("TButton", font=("Segoe UI", 10, "bold"))
        style.configure("Header.TLabel", font=("Segoe UI", 14, "bold"), foreground="#1d4ed8")

    def _create_widgets(self):
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)

        title = ttk.Label(main_frame, text="Sistema de gestión de estudiantes", style="Header.TLabel")
        title.pack(pady=(0, 15))

        form_frame = ttk.Frame(main_frame)
        form_frame.pack(fill=tk.X, pady=(0, 15))

        ttk.Label(form_frame, text="Nombre:").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=6)
        self.nombre_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.nombre_var, width=30).grid(row=0, column=1, sticky="ew", pady=6)

        ttk.Label(form_frame, text="Edad:").grid(row=0, column=2, sticky="w", padx=(20, 10), pady=6)
        self.edad_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.edad_var, width=12).grid(row=0, column=3, sticky="ew", pady=6)

        ttk.Label(form_frame, text="Curso:").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=6)
        self.curso_var = tk.StringVar(value=CARRERAS[0])
        ttk.Combobox(form_frame, textvariable=self.curso_var, values=CARRERAS, state="readonly", width=28).grid(
            row=1, column=1, sticky="ew", pady=6
        )

        ttk.Label(form_frame, text="Calificaciones:").grid(row=1, column=2, sticky="w", padx=(20, 10), pady=6)
        self.calificaciones_var = tk.StringVar()
        ttk.Entry(form_frame, textvariable=self.calificaciones_var, width=30).grid(row=1, column=3, sticky="ew", pady=6)

        form_frame.columnconfigure(1, weight=1)
        form_frame.columnconfigure(3, weight=1)

        buttons_frame = ttk.Frame(main_frame)
        buttons_frame.pack(fill=tk.X, pady=(0, 15))

        ttk.Button(buttons_frame, text="Registrar estudiante", command=self.guardar_estudiante).pack(
            side=tk.LEFT, padx=(0, 10)
        )
        ttk.Button(buttons_frame, text="Mostrar todos", command=self.cargar_estudiantes).pack(
            side=tk.LEFT, padx=(0, 10)
        )
        ttk.Button(buttons_frame, text="Buscar", command=self.buscar_estudiante).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(buttons_frame, text="Resumen", command=self.mostrar_resumen).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(buttons_frame, text="Limpiar", command=self.limpiar_campos).pack(side=tk.LEFT)

        search_frame = ttk.Frame(main_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(search_frame, text="Buscar por nombre:").pack(side=tk.LEFT, padx=(0, 10))
        self.buscar_var = tk.StringVar()
        ttk.Entry(search_frame, textvariable=self.buscar_var, width=35).pack(side=tk.LEFT)

        self.table = ttk.Treeview(
            main_frame,
            columns=("id", "nombre", "edad", "curso", "promedio", "estado"),
            show="headings",
        )
        self.table.heading("id", text="ID")
        self.table.heading("nombre", text="Nombre")
        self.table.heading("edad", text="Edad")
        self.table.heading("curso", text="Curso")
        self.table.heading("promedio", text="Promedio")
        self.table.heading("estado", text="Estado")

        self.table.column("id", width=60, anchor="center")
        self.table.column("nombre", width=180)
        self.table.column("edad", width=70, anchor="center")
        self.table.column("curso", width=180)
        self.table.column("promedio", width=90, anchor="center")
        self.table.column("estado", width=120, anchor="center")

        self.table_scroll = ttk.Scrollbar(main_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=self.table_scroll.set)

        self.table.pack(fill=tk.BOTH, expand=True)
        self.table_scroll.pack(fill=tk.Y, side=tk.RIGHT)

        self.resumen_text = tk.Text(main_frame, height=8, wrap=tk.WORD, bg="#ffffff", fg="#111827")
        self.resumen_text.pack(fill=tk.BOTH, expand=True, pady=(10, 0))

        self.cargar_estudiantes()
        self.mostrar_resumen()

    def limpiar_campos(self):
        self.nombre_var.set("")
        self.edad_var.set("")
        self.curso_var.set(CARRERAS[0])
        self.calificaciones_var.set("")

    def cargar_estudiantes(self):
        for item in self.table.get_children():
            self.table.delete(item)

        rows = obtener_todos_estudiantes()
        for row in rows:
            self.table.insert(
                "",
                tk.END,
                values=(
                    row["id"],
                    row["nombre"],
                    row["edad"],
                    row["curso"],
                    row["promedio"],
                    row["estado"],
                ),
            )

    def guardar_estudiante(self):
        nombre = self.nombre_var.get().strip()
        edad = self.edad_var.get().strip()
        curso = self.curso_var.get().strip()
        calificaciones = self.calificaciones_var.get().strip()

        if not nombre:
            messagebox.showwarning("Datos faltantes", "Ingresa el nombre del estudiante.")
            return

        if not edad or not edad.isdigit():
            messagebox.showwarning("Edad inválida", "La edad debe ser un número válido.")
            return

        if not curso:
            messagebox.showwarning("Curso requerido", "Selecciona un curso.")
            return

        if not calificaciones:
            messagebox.showwarning("Calificaciones faltantes", "Ingresa al menos una calificación.")
            return

        notas = convertir_a_lista(calificaciones)
        if not notas:
            messagebox.showwarning(
                "Calificaciones inválidas",
                "Usa números separados por coma entre 0 y 20, por ejemplo: 18,15,20",
            )
            return

        promedio = calcular_promedio(notas)
        estado = obtener_estado(promedio)

        registrar_estudiante(nombre, int(edad), curso, calificaciones, promedio, estado)
        messagebox.showinfo("Registro exitoso", f"Estudiante registrado correctamente.\nPromedio: {promedio}\nEstado: {estado}")
        self.limpiar_campos()
        self.cargar_estudiantes()
        self.mostrar_resumen()

    def buscar_estudiante(self):
        criterio = self.buscar_var.get().strip()
        if not criterio:
            messagebox.showwarning("Búsqueda vacía", "Escribe un nombre para buscar.")
            return

        rows = buscar_estudiante(criterio)
        for item in self.table.get_children():
            self.table.delete(item)

        if not rows:
            messagebox.showinfo("Sin resultados", "No se encontraron estudiantes con ese nombre.")
            return

        for row in rows:
            self.table.insert(
                "",
                tk.END,
                values=(
                    row["id"],
                    row["nombre"],
                    row["edad"],
                    row["curso"],
                    row["promedio"],
                    row["estado"],
                ),
            )

    def mostrar_resumen(self):
        rows = obtener_resumen()
        self.resumen_text.delete("1.0", tk.END)

        if not rows:
            self.resumen_text.insert(tk.END, "No hay estudiantes registrados.")
            return

        aprobados = [r for r in rows if r["estado"] == "Aprobado"]
        reprobados = [r for r in rows if r["estado"] == "Reprobado"]

        self.resumen_text.insert(tk.END, f"Aprobados: {len(aprobados)}\n")
        for row in aprobados:
            self.resumen_text.insert(tk.END, f"- {row['nombre']} ({row['curso']}) -> {row['promedio']}\n")

        self.resumen_text.insert(tk.END, f"\nReprobados: {len(reprobados)}\n")
        for row in reprobados:
            self.resumen_text.insert(tk.END, f"- {row['nombre']} ({row['curso']}) -> {row['promedio']}\n")


def crear_interfaz():
    app = StudentManagerApp()
    app.mainloop()
