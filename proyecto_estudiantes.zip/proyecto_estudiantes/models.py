CARRERAS = [
    "Informatica",
    "Electronica",
    "Enfermeria",
    "Diseño de moda",
    "Comercio exterior",
    "Diseño Grafico",
]


def calcular_promedio(calificaciones):
    if not calificaciones:
        return 0.0
    promedio = sum(calificaciones) / len(calificaciones)
    return round(promedio, 2)


def convertir_a_lista(calificaciones_texto):
    if not calificaciones_texto:
        return []

    valores = []
    for item in calificaciones_texto.replace(";", ",").split(","):
        valor = item.strip()
        if valor:
            try:
                numero = float(valor)
                if 0 <= numero <= 20:
                    valores.append(numero)
                else:
                    return []
            except ValueError:
                return []
    return valores


def obtener_estado(promedio):
    return "Aprobado" if promedio >= 10 else "Reprobado"
