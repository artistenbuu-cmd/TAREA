from database import crear_tabla
from gui import crear_interfaz


if __name__ == "__main__":
    crear_tabla()
    crear_interfaz()
